import { createElement } from "lwc";
import FeedbackList from "c/feedbackList";
import { createTestWireAdapter } from '@salesforce/wire-service-jest-util';
import getFeedbackRecords from "@salesforce/apex/FeedbackController.getFeedbackRecords";

const getRecords = createTestWireAdapter(getFeedbackRecords);

// Mock the Apex method
// jest.mock(
//   "@salesforce/apex/FeedbackController.getFeedbackRecords",
//   () => {
//     return {
//       default: jest.fn()
//     };
//   },
//   { virtual: true }
// );

describe("c-feedback-list", () => {
  afterEach(() => {
    // The jsdom instance is shared across test cases in a single file so reset the DOM
    while (document.body.firstChild) {
      document.body.removeChild(document.body.firstChild);
    }
    // jest.clearAllMocks();
  });

  it("renders feedback records", () => {
    const mockFeedbackRecords = [
      {
        // Id: "123",
        CustomerName: "John Doe",
        Rating__c: 5,
        Feedback_Text__c: "Great!",
        Sentiment__c: "Positive"
      },
      {
        // Id: "456",
        CustomerName: "Lorem Ipsum",
        Rating__c: 3,
        Feedback_Text__c: "Okay!",
        Sentiment__c: "Neutral"
      }
    ];

    // Mock the Apex method to return data
    // getFeedbackRecords.mockResolvedValue(mockFeedbackRecords);

    // Create component instance
    const element = createElement("c-feedback-list", { is: FeedbackList });
    document.body.appendChild(element);

    // Emit mock record into the wired field
    getRecords.emit(mockFeedbackRecords);

    // Wait for any async updates
    return Promise.resolve().then(() => {
        const datatable = element.shadowRoot.querySelector("lightning-datatable");
        console.log('datatable: ', datatable.data)
        
        const rows = datatable.data;
        expect(rows.length).toBe(2); // Expected 2 rows
    });
  });

  it("renders no data when Apex method returns empty array", async () => {
    // Mock the Apex method to return an empty array
    getFeedbackRecords.mockResolvedValue([]);

    // Create component instance
    const element = createElement("c-feedback-list", { is: FeedbackList });
    document.body.appendChild(element);

    // Wait for any async updates
    await Promise.resolve();

    const datatable = element.shadowRoot.querySelector("lightning-datatable");
    expect(datatable.data).toEqual([]); // Expected no rows
  });
});
